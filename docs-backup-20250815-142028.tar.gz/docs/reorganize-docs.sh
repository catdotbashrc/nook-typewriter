#!/bin/bash
# Documentation Reorganization Script for Nook Typewriter Project
# Moves 47 scattered files into 12 organized categories

set -euo pipefail

echo "═══════════════════════════════════════════════════════════════"
echo "     📁 Documentation Reorganization Script"
echo "     Moving 47 files → 12 organized categories"
echo "═══════════════════════════════════════════════════════════════"
echo ""

# Safety check
if [ ! -d "docs" ]; then
    echo "❌ Error: Must run from project root directory"
    exit 1
fi

# Confirmation
read -p "This will reorganize all documentation. Continue? (y/N): " -n 1 -r
echo
if [[ ! $REPLY =~ ^[Yy]$ ]]; then
    echo "Cancelled."
    exit 0
fi

echo ""
echo "📁 Creating new directory structure..."

# Create all new directories
mkdir -p docs/{indexes,getting-started,build,jesteros,api-reference}
mkdir -p docs/{configuration,testing,ui-design,troubleshooting}
mkdir -p docs/indexes/archive

echo "✅ Directory structure created"
echo ""

# Function to safely move files
move_file() {
    local src="$1"
    local dest="$2"
    if [ -f "$src" ]; then
        mv "$src" "$dest"
        echo "  ✓ Moved: $(basename "$src")"
    fi
}

# 1. Index files
echo "📚 Moving index and navigation files..."
move_file "docs/COMPREHENSIVE_DOCUMENTATION_INDEX.md" "docs/indexes/COMPREHENSIVE_INDEX.md"
move_file "docs/DOCUMENTATION_NAVIGATION.md" "docs/indexes/NAVIGATION.md"
move_file "docs/DOCUMENTATION_CONSOLIDATION_PLAN.md" "docs/indexes/CONSOLIDATION_PLAN.md"
move_file "docs/REORGANIZATION_PLAN.md" "docs/indexes/"
move_file "docs/API_NAVIGATION_INDEX.md" "docs/indexes/archive/"
move_file "docs/COMPLETE_PROJECT_INDEX.md" "docs/indexes/archive/"
move_file "docs/BOOT_DOCUMENTATION_INDEX.md" "docs/indexes/archive/"
move_file "docs/NST_KERNEL_INDEX.md" "docs/indexes/archive/"

# 2. Getting Started
echo ""
echo "🚀 Moving getting started guides..."
move_file "docs/SD_CARD_BOOT_GUIDE.md" "docs/getting-started/"
move_file "docs/BOOT_GUIDE_CONSOLIDATED.md" "docs/getting-started/"
move_file "docs/COMPLETE_BOOT_GUIDE.md" "docs/getting-started/"
move_file "docs/guides/QUICK_BOOT_GUIDE.md" "docs/getting-started/"

# 3. Build System
echo ""
echo "🏗️ Moving build documentation..."
move_file "docs/BUILD_ARCHITECTURE.md" "docs/build/"
move_file "docs/BUILD_SYSTEM_DOCUMENTATION.md" "docs/build/"
move_file "docs/KERNEL_BUILD_GUIDE.md" "docs/build/"
move_file "docs/KERNEL_BUILD_EXPLAINED.md" "docs/build/"
move_file "docs/ROOTFS_BUILD.md" "docs/build/"
move_file "docs/XDA-RESEARCH-FINDINGS.md" "docs/build/"

# 4. JesterOS
echo ""
echo "🎭 Moving JesterOS documentation..."
move_file "docs/JESTEROS_API_COMPLETE.md" "docs/jesteros/"
move_file "docs/JESTEROS_USERSPACE_SOLUTION.md" "docs/jesteros/"
move_file "docs/JESTEROS_BREAKTHROUGH_ANALYSIS.md" "docs/jesteros/"
move_file "docs/JESTEROS_DEBUG_LOG.md" "docs/jesteros/"
move_file "docs/MIGRATION_TO_USERSPACE.md" "docs/jesteros/"
move_file "docs/ASCII_ART_ADVANCED.md" "docs/jesteros/"

# 5. Kernel (move additional files to existing dir)
echo ""
echo "⚙️ Moving kernel documentation..."
move_file "docs/KERNEL_API_REFERENCE.md" "docs/kernel/"
move_file "docs/KERNEL_MODULES_GUIDE.md" "docs/kernel/"
move_file "docs/MODULE_API_QUICK_REFERENCE.md" "docs/kernel/"
# Keep existing files in kernel/

# 6. API Reference
echo ""
echo "📝 Moving API documentation..."
move_file "docs/SOURCE_API_DOCUMENTATION.md" "docs/api-reference/"
move_file "docs/SOURCE_API_REFERENCE.md" "docs/api-reference/"
move_file "docs/SCRIPTS_CATALOG.md" "docs/api-reference/"
move_file "docs/SCRIPTS_DOCUMENTATION_COMPLETE.md" "docs/api-reference/"

# 7. Configuration
echo ""
echo "🔧 Moving configuration documentation..."
move_file "docs/CONFIGURATION.md" "docs/configuration/"
move_file "docs/CONFIGURATION_INDEX.md" "docs/configuration/"
move_file "docs/CONFIGURATION_REFERENCE.md" "docs/configuration/"
move_file "docs/CONSOLE_FONTS_COMPATIBILITY.md" "docs/configuration/"

# 8. Deployment (move additional files to existing dir)
echo ""
echo "📦 Moving deployment documentation..."
move_file "docs/DEPLOYMENT_DOCUMENTATION.md" "docs/deployment/"
move_file "docs/DEPLOYMENT_INTEGRATION_GUIDE.md" "docs/deployment/"
move_file "docs/DEPLOYMENT_UPDATES.md" "docs/deployment/"
# Keep existing files in deployment/

# 9. Testing
echo ""
echo "🧪 Moving testing documentation..."
move_file "docs/TEST_SUITE_DOCUMENTATION.md" "docs/testing/"
move_file "docs/TEST_FRAMEWORK_REFERENCE.md" "docs/testing/"
move_file "docs/TESTING_PROCEDURES.md" "docs/testing/"
move_file "docs/TESTING_WORKFLOW.md" "docs/testing/"
move_file "docs/DEVELOPER_TESTING_GUIDE.md" "docs/testing/"

# 10. UI Design
echo ""
echo "🎨 Moving UI documentation..."
move_file "docs/ui-components-design.md" "docs/ui-design/"
move_file "docs/ui-iterative-refinement.md" "docs/ui-design/"
move_file "docs/BOOT_SPLASH_IMPLEMENTATION.md" "docs/ui-design/"

# 11. Troubleshooting
echo ""
echo "🔍 Moving troubleshooting guides..."
move_file "docs/BOOT_LOOP_FIX.md" "docs/troubleshooting/"
move_file "docs/ISSUE_18_SOLUTION.md" "docs/troubleshooting/"

# 12. Guides
echo ""
echo "📖 Moving style guides..."
move_file "docs/QUILLOS_STYLE_GUIDE.md" "docs/guides/"
# Keep BUILD_INFO in guides/

# Clean up empty planning directory
if [ -d "docs/planning" ] && [ -z "$(ls -A docs/planning)" ]; then
    rmdir docs/planning
    echo ""
    echo "🧹 Removed empty planning directory"
fi

# Move this script to indexes for reference
cp "$0" "docs/indexes/reorganize-docs.sh" 2>/dev/null || true

echo ""
echo "═══════════════════════════════════════════════════════════════"
echo "✅ Reorganization Complete!"
echo ""
echo "📊 Summary:"
echo "  • Files moved: $(find docs -type f -name "*.md" | wc -l)"
echo "  • Categories: 12"
echo "  • Base level files: $(ls -1 docs/*.md 2>/dev/null | wc -l || echo 0)"
echo ""
echo "📝 Next steps:"
echo "  1. Update cross-references in moved files"
echo "  2. Update README.md to point to new locations"
echo "  3. Test all documentation links"
echo "  4. Commit changes with message: 'docs: reorganize into 12 categories'"
echo ""
echo "═══════════════════════════════════════════════════════════════"