# 📋 Configuration Files Documentation

*Complete guide to JesterOS/Nook Typewriter configuration system*

**Version**: 1.0.0  
**Updated**: December 2024  
**Location**: `source/configs/`

---

## 🎯 Overview

The configuration system provides centralized settings for the entire Nook Typewriter environment, from boot parameters to writing environment customization. All configurations are designed to be E-Ink friendly and memory-efficient.

### Configuration Philosophy
- **Writer-First**: Every setting prioritizes writing experience
- **E-Ink Optimized**: Display settings tuned for 800x600 grayscale
- **Medieval Themed**: Whimsical jester personality throughout
- **Memory Conscious**: Minimal RAM usage (< 96MB total OS)

---

## 📁 Directory Structure

```
source/configs/
├── ascii/                  # ASCII art collections
│   ├── jester/            # Jester personality art
│   └── jester-collection.txt
├── services/              # Service configurations
├── system/                # System-level configs
├── vim/                   # Vim editor configurations
├── zk-templates/          # Zettelkasten templates
├── nook.conf             # Master configuration
└── zk-config.toml        # Zettelkasten config
```

---

## 🔧 Core Configuration Files

### Master Configuration (`nook.conf`)

**Purpose**: Central configuration hub for all Nook scripts and services

**Key Sections**:
- **System Paths**: Project directories, user data locations
- **Hardware Settings**: SD card, E-Ink display, memory constraints
- **Software Config**: Editor, menu, sync settings
- **Boot Parameters**: Kernel version, cmdline, bootloader
- **JesterOS Settings**: Medieval theme, writing statistics
- **Development**: Debug, logging, testing modes
- **Power Management**: Battery optimization, USB power limits

**Usage**:
```bash
source /path/to/nook.conf
value=$(get_config "NOOK_EDITOR" "vim")
```

**Key Variables**:
- `NOOK_TOTAL_RAM_MB=256` - Total system RAM
- `NOOK_AVAILABLE_RAM_MB=160` - RAM reserved for writing
- `NOOK_DISPLAY_WIDTH=800` - E-Ink width
- `NOOK_DISPLAY_HEIGHT=600` - E-Ink height
- `NOOK_ENABLE_JESTER=true` - Enable jester personality

---

## 🎨 ASCII Art Configuration

### Location: `ascii/jester/`

ASCII art collections for the jester personality system, providing visual feedback and whimsy throughout the user experience.

#### Files:
- **`jester-logo.txt`**: Main boot splash screen art
- **`jester-variations.txt`**: Different jester moods and sizes
- **`silly-jester-collection.txt`**: Humorous variations
- **`medieval-elements.txt`**: Decorative medieval elements
- **`system-messages.txt`**: Status and error message art

#### Usage Example:
```bash
# Display boot splash
cat /etc/jesteros/ascii/jester-logo.txt

# Show mood based on system state
jester_mood=$(cat /var/jesteros/jester)
```

---

## ⚙️ System Configuration

### Location: `system/`

Core system files defining the OS identity, boot services, and system behavior.

#### Key Files:

##### `os-release`
- **Purpose**: System identification
- **Key Values**:
  - `NAME="SquireOS"`
  - `VERSION="1.0.0"`
  - `PRETTY_NAME="SquireOS 1.0.0 (Parchment)"`
  - `MASCOT="The Derpy Court Jester"`

##### `motd` (Message of the Day)
- **Purpose**: Welcome message on login
- **Content**: Medieval-themed writing encouragement

##### `fstab`
- **Purpose**: Filesystem mount configuration
- **Key Mounts**:
  - `/dev/mmcblk0p1` → `/boot` (FAT32)
  - `/dev/mmcblk0p2` → `/` (ext4)
  - `tmpfs` → `/tmp` (RAM disk, 32MB)

##### Service Files:
- `jester.service` - Jester mood daemon
- `squireos-boot.service` - Boot initialization
- `squireos-modules.service` - Kernel module loading
- `jesteros.init` - Init script for JesterOS services

##### `sysctl.conf`
- **Purpose**: Kernel parameter tuning
- **Key Settings**:
  - `vm.swappiness=10` - Minimize swap usage
  - `vm.dirty_ratio=5` - Aggressive write-back
  - `kernel.printk=3 3 3 3` - Reduce console spam

---

## ✏️ Vim Configuration

### Location: `vim/`

Multiple Vim configurations optimized for different writing scenarios on E-Ink displays.

#### Configuration Files:

##### `vimrc-writer` (Primary)
- **Purpose**: Optimized for prose writing
- **Features**:
  - Goyo, Pencil, Litecorrect plugins only
  - ~5MB RAM usage
  - E-Ink friendly (no syntax highlighting)
  - Auto-save every 3 minutes
  - Spell checking enabled

##### `vimrc-minimal`
- **Purpose**: Emergency/recovery mode
- **Features**:
  - No plugins
  - < 2MB RAM usage
  - Basic editing only

##### `vimrc`
- **Purpose**: Standard configuration
- **Features**:
  - Balanced feature set
  - Some visual aids
  - ~8MB RAM usage

##### `vimrc-zk`
- **Purpose**: Zettelkasten note-taking
- **Features**:
  - Note linking support
  - Template integration
  - Tag management

##### `eink.vim`
- **Purpose**: E-Ink display color scheme
- **Features**:
  - High contrast
  - No colors (grayscale)
  - Large fonts

---

## 🔧 Service Configuration

### Location: `services/`

Configuration for JesterOS userspace services.

#### Service Files:

##### `jester.conf`
```bash
SERVICE_NAME="Court Jester"
SERVICE_DESC="ASCII art mood daemon"
SERVICE_EXEC="/usr/local/bin/jester-daemon.sh"
SERVICE_MEM_LIMIT=512  # KB
SERVICE_RESTART=true
```

##### `tracker.conf`
```bash
SERVICE_NAME="Writing Tracker"
SERVICE_DESC="Keystroke and word counting"
SERVICE_EXEC="/usr/local/bin/tracker-daemon.sh"
SERVICE_MEM_LIMIT=256  # KB
```

##### `health.conf`
```bash
SERVICE_NAME="System Health"
SERVICE_DESC="Memory and resource monitoring"
SERVICE_EXEC="/usr/local/bin/health-daemon.sh"
SERVICE_MEM_LIMIT=256  # KB
```

---

## 📝 Zettelkasten Configuration

### Files:
- **`zk-config.toml`**: Main Zettelkasten configuration
- **`zk-templates/default.md`**: Default note template
- **`zk-templates/daily.md`**: Daily note template

### Configuration (`zk-config.toml`):
```toml
[notebook]
dir = "~/notes"

[note]
extension = "md"
template = "default.md"
id-regex = "[0-9]{14}"

[format]
markdown-link-format = "wiki"
```

---

## 🔐 Configuration Management

### Loading Configuration
```bash
# In shell scripts
source /etc/nook.conf

# Check if feature enabled
if is_enabled "NOOK_ENABLE_JESTER"; then
    start_jester_service
fi

# Get config with default
editor=$(get_config "NOOK_EDITOR" "vim")
```

### Configuration Validation
```bash
# Validate all settings
validate_config || exit 1

# Export all NOOK_* variables
export_config
```

### Local Overrides
Create `nook.conf.local` for machine-specific settings:
```bash
# Override default editor
NOOK_EDITOR="nano"

# Custom notes directory
NOOK_NOTES_DIR="/mnt/sd/notes"
```

---

## 🎮 Usage Examples

### Starting Services with Configuration
```bash
# Load service config and start
source /etc/jesteros/services/jester.conf
$SERVICE_EXEC $SERVICE_ARGS
```

### Applying Vim Configuration
```bash
# Use writer-optimized config
vim -u /etc/vim/vimrc-writer document.txt

# Use minimal config for quick edits
vim -u /etc/vim/vimrc-minimal note.txt
```

### Displaying ASCII Art
```bash
# Show boot splash
cat /etc/jesteros/ascii/jester-logo.txt

# Random jester mood
shuf -n 1 /etc/jesteros/ascii/jester-variations.txt
```

---

## 🚀 Boot Configuration

### Boot Environment (`boot/uEnv.txt`)
```
bootargs=console=ttyS0,115200n8 root=/dev/mmcblk0p2 rootfstype=ext4 rw rootwait mem=256M
bootcmd=mmc init; fatload mmc 0 0x80300000 uImage; bootm 0x80300000
```

### Kernel Command Line
- `mem=256M` - Limit kernel to 256MB
- `console=ttyS0,115200n8` - Serial console
- `root=/dev/mmcblk0p2` - Root partition
- `init=/sbin/init` - Init system

---

## 💾 Memory Budgets

### Configured Limits:
- **Total System**: 96MB maximum
- **JesterOS Services**: 8MB combined
  - Jester: 512KB
  - Tracker: 256KB
  - Health: 256KB
- **Vim Editor**: 5-10MB depending on config
- **Reserved for Writing**: 160MB minimum

---

## 🔍 Troubleshooting

### Common Issues:

**Configuration not loading**:
```bash
# Check file exists and is readable
test -r /etc/nook.conf || echo "Config not found"

# Validate syntax
bash -n /etc/nook.conf
```

**Service failing to start**:
```bash
# Check service config
source /etc/jesteros/services/jester.conf
test -x "$SERVICE_EXEC" || echo "Executable not found"
```

**Vim using too much RAM**:
```bash
# Switch to minimal config
alias vim='vim -u /etc/vim/vimrc-minimal'
```

---

## 📊 Configuration Statistics

- **Total Config Files**: 30+
- **ASCII Art Variations**: 15+ jester moods
- **Vim Configurations**: 5 optimized profiles
- **Service Definitions**: 3 core services
- **System Files**: 12 system configs
- **Memory Budget**: < 1MB for all configs

---

## 🏰 Philosophy

> "Configuration is the foundation of a stable writing environment"

All configurations follow these principles:
1. **Simplicity**: Easy to understand and modify
2. **Performance**: Minimal resource usage
3. **Reliability**: Fail-safe defaults
4. **Whimsy**: Medieval charm throughout

---

*"By quill and candlelight, we configure for those who write"* 📜

*Generated with [Claude Code](https://claude.ai/code)*