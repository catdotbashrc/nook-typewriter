# 📚 JesterOS Source API Documentation

*Last Updated: August 15, 2025*  
*Version: 2.0.0 - Userspace Architecture*

## Table of Contents

1. [Overview](#overview)
2. [Architecture](#architecture)
3. [Boot System API](#boot-system-api)
4. [Service Management API](#service-management-api)
5. [Menu System API](#menu-system-api)
6. [Library Functions API](#library-functions-api)
7. [Kernel Integration](#kernel-integration)
8. [Interface Specifications](#interface-specifications)
9. [Data Structures](#data-structures)
10. [Error Handling](#error-handling)

---

## Overview

The JesterOS source directory contains the complete implementation of a distraction-free writing environment for the Nook Simple Touch e-reader. This API documentation covers all public interfaces, service contracts, and integration points.

### Key Components

| Component | Location | Purpose |
|-----------|----------|---------|
| **Boot Scripts** | `source/scripts/boot/` | System initialization and service startup |
| **Services** | `source/scripts/services/` | Userspace daemons and monitors |
| **Menu System** | `source/scripts/menu/` | User interface and navigation |
| **Libraries** | `source/scripts/lib/` | Shared utilities and functions |
| **Kernel** | `source/kernel/` | Linux 2.6.29 with JesterOS modules |

---

## Architecture

### System Layers

```
┌─────────────────────────────────────┐
│         User Interface Layer         │
│       (Menu System, Display)         │
├─────────────────────────────────────┤
│       Service Management Layer       │
│    (Daemons, Monitors, Trackers)    │
├─────────────────────────────────────┤
│        Core Library Layer           │
│    (Common Functions, Utilities)    │
├─────────────────────────────────────┤
│         Boot System Layer           │
│    (Initialization, Modules)        │
├─────────────────────────────────────┤
│          Kernel Layer               │
│    (Linux 2.6.29 + Modules)         │
└─────────────────────────────────────┘
```

---

## Boot System API

### init-jesteros.sh

**Purpose**: Primary system initialization script

**Location**: `source/scripts/boot/init-jesteros.sh`

**Functions**:

#### Main Initialization
```bash
# No parameters - called directly at boot
/usr/local/bin/init-jesteros.sh
```

**Behavior**:
1. Creates directory structure (`/var/jesteros/`, `/var/run/jesteros/`)
2. Copies service configurations
3. Starts service manager
4. Initializes interface files
5. Launches menu if interactive

**Exit Codes**:
- `0`: Successful initialization
- `1`: Directory creation failed
- `2`: Service manager not found

### boot-jester.sh

**Purpose**: Legacy boot with kernel module support

**Location**: `source/scripts/boot/boot-jester.sh`

**Functions**:

```bash
init_display()              # Initialize E-Ink or terminal display
load_jesteros_modules()     # Load kernel modules (optional)
main()                      # Main boot sequence
```

**Environment Variables**:
- `COMMON_PATH`: Path to common.sh library
- `BOOT_DELAY`: Delay before menu launch (seconds)

### jesteros-userspace.sh

**Purpose**: Create userspace service interface

**Location**: `source/scripts/boot/jesteros-userspace.sh`

**Functions**:

```bash
create_jesteros_dirs()      # Create /var/jesteros structure
init_jester()              # Initialize ASCII art interface
init_typewriter()          # Initialize statistics
init_wisdom()              # Initialize quotes
start_services()           # Start userspace services
```

**Interface Files Created**:
- `/var/jesteros/jester`: ASCII art display
- `/var/jesteros/typewriter/stats`: Writing statistics
- `/var/jesteros/wisdom`: Writing quotes

---

## Service Management API

### jesteros-service-manager.sh

**Purpose**: Central service orchestration

**Location**: `source/scripts/services/jesteros-service-manager.sh`

**Usage**:
```bash
jesteros-service-manager.sh <command> [target]

Commands:
  start   [service|all]    Start service(s)
  stop    [service|all]     Stop service(s)
  restart [service|all]     Restart service(s)
  status  [service|all]     Check status
  health  [service|all]     Health check
  monitor                   Continuous monitoring
  init                      System initialization
```

**Functions**:

```bash
start_all_services()        # Start in dependency order
stop_all_services()         # Stop in reverse order
health_check_all()          # Comprehensive health check
monitor_services()          # Daemon mode monitoring
resolve_dependencies()      # Handle service deps
auto_restart_service()      # Restart with backoff
```

**Service Configuration Format**:
```bash
SERVICE_NAME="Display Name"
SERVICE_DESC="Description"
SERVICE_EXEC="/path/to/executable"
SERVICE_PIDFILE="/var/run/jesteros/service.pid"
SERVICE_ARGS="--daemon"
SERVICE_DEPS="dep1 dep2"
SERVICE_HEALTH_CHECK="test command"
```

### jester-daemon.sh

**Purpose**: ASCII art companion with mood system

**Location**: `source/scripts/services/jester-daemon.sh`

**Usage**:
```bash
jester-daemon.sh [start|stop|status] [--daemon]
```

**Mood States**:
- `happy`: Default, system healthy
- `writing`: Active writing detected
- `thinking`: High CPU usage
- `sleeping`: Idle > 5 minutes
- `error`: System issues
- `celebrating`: Achievement unlocked

**Interface API**:
```bash
# Read current jester
cat /var/jesteros/jester

# Read current mood
cat /var/jesteros/jester/mood

# Activity statistics
cat /var/jesteros/jester/stats
```

### jesteros-tracker.sh

**Purpose**: Writing statistics and achievement tracking

**Location**: `source/scripts/services/jesteros-tracker.sh`

**Functions**:

```bash
update_stats()              # Update writing statistics
check_achievements()        # Check for new achievements
monitor_writing()           # Monitor file changes
```

**Statistics Format**:
```
Words: 12,847
Characters: 67,234
Keystrokes: 89,156
Sessions: 47
Total Time: 23h 18m
Streak: 12 days
Achievement: Master Wordsmith
```

**Achievements**:
- `APPRENTICE_SCRIBE`: 100 words
- `JOURNEYMAN_WRITER`: 1,000 words
- `MASTER_WORDSMITH`: 10,000 words
- `GRAND_CHRONICLER`: 100,000 words

### health-check.sh

**Purpose**: System health monitoring

**Location**: `source/scripts/services/health-check.sh`

**Health Checks**:
1. Memory usage (< 96MB limit)
2. Disk space availability
3. CPU load averages
4. Service status verification

**Output Format**:
```bash
# Read health status
cat /var/jesteros/health/status

# Format:
# HEALTH: [excellent|good|warning|critical]
# Memory: XX/96MB
# Disk: X.XGB free
# Services: X/X running
```

---

## Menu System API

### nook-menu.sh

**Purpose**: Main writing environment menu

**Location**: `source/scripts/menu/nook-menu.sh`

**Menu Structure**:
```
1. New Manuscript (Zettelkasten)
2. Continue Draft
3. Resume Last Session
4. View Statistics
5. Visit the Jester
6. Shutdown
```

**Functions**:

```bash
display_menu()              # Show menu options
handle_choice()             # Process user selection
launch_vim()                # Start writing session
show_statistics()           # Display writing stats
```

**Input Validation**:
```bash
validate_menu_choice()      # Validate numeric input
validate_path()             # Prevent path traversal
```

### squire-menu.sh

**Purpose**: Medieval-themed alternative menu

**Location**: `source/scripts/menu/squire-menu.sh`

**Menu Options**:
- `S`: Scribe (New Manuscript)
- `C`: Chronicle (Statistics)
- `I`: Illuminate (Continue)
- `W`: Wisdom (Quotes)
- `Q`: Quest Complete (Exit)

---

## Library Functions API

### common.sh

**Purpose**: Shared utilities and safety functions

**Location**: `source/scripts/lib/common.sh`

**Core Functions**:

#### Display Management
```bash
display_text(text, refresh)  # Display with E-Ink support
clear_display()              # Clear screen properly
display_banner(title)        # Show formatted banner
has_eink()                   # Check E-Ink availability
```

#### Input Validation
```bash
validate_menu_choice(choice, max)  # Validate menu input
validate_path(path)                # Prevent traversal
sanitize_input(input)              # Remove control chars
```

#### Error Handling
```bash
error_handler(line_no, exit_code)  # Unified error handler
log_message(level, message)        # Structured logging
debug_log(message)                 # Debug output
```

**Constants**:
```bash
JESTER_DIR="/var/lib/jester"
NOTES_DIR="/root/notes"
DRAFTS_DIR="/root/drafts"
SCROLLS_DIR="/root/scrolls"
BOOT_DELAY=2
MENU_TIMEOUT=3
```

### service-functions.sh

**Purpose**: Service management utilities

**Location**: `source/scripts/lib/service-functions.sh`

**Functions**:

```bash
load_service_config(service)       # Load configuration
is_service_running(pidfile)        # Check process
start_service(service)              # Start with logging
stop_service(service)               # Clean shutdown
health_check_service(service)       # Health verification
resolve_dependencies(service)       # Dependency order
```

---

## Kernel Integration

### Module Interface

**Location**: `source/kernel/`

**Kernel Modules** (Optional):
- `jesteros_core.ko`: Base infrastructure
- `jester.ko`: ASCII art engine
- `typewriter.ko`: Statistics tracking
- `wisdom.ko`: Quote system

**Proc Interface** (Legacy):
```bash
/proc/jesteros/
├── jester          # ASCII art
├── typewriter/     # Statistics
└── wisdom          # Quotes
```

---

## Interface Specifications

### Filesystem Interface

**Primary Location**: `/var/jesteros/`

```
/var/jesteros/
├── jester                  # Current ASCII art
├── jester/
│   ├── mood               # Current mood
│   └── stats              # Activity stats
├── typewriter/
│   ├── stats              # Writing statistics
│   ├── achievements       # Unlocked achievements
│   └── daily              # Daily progress
├── health/
│   ├── status             # Overall health
│   ├── memory             # Memory details
│   └── services           # Service status
├── wisdom                  # Current quote
└── services/
    └── status             # Service manager status
```

### Service Communication

**PID Files**: `/var/run/jesteros/*.pid`
**Log Files**: `/var/log/jesteros/*.log`
**Config Files**: `/etc/jesteros/services/*.conf`

---

## Data Structures

### Service Status
```bash
{
  "name": "service_name",
  "status": "running|stopped|error",
  "pid": 12345,
  "memory": "2.1MB",
  "cpu": "0.1%",
  "uptime": "2h 15m"
}
```

### Writing Statistics
```bash
{
  "words": 12847,
  "characters": 67234,
  "keystrokes": 89156,
  "sessions": 47,
  "total_time": "23h 18m",
  "streak": 12,
  "last_write": "2025-08-15 14:30:22",
  "today": 347,
  "goal": 500,
  "achievement": "Master Wordsmith"
}
```

### Health Report
```bash
{
  "health": "excellent|good|warning|critical",
  "memory": {
    "used": 67,
    "total": 96,
    "percent": 70
  },
  "disk": {
    "free_gb": 2.3,
    "status": "excellent"
  },
  "cpu": {
    "load_1": 0.15,
    "load_5": 0.23,
    "load_15": 0.18
  },
  "services": {
    "running": 3,
    "total": 3,
    "failed": []
  }
}
```

---

## Error Handling

### Standard Error Codes

| Code | Meaning | Recovery |
|------|---------|----------|
| 0 | Success | - |
| 1 | General error | Check logs |
| 2 | File not found | Verify paths |
| 3 | Permission denied | Check permissions |
| 4 | Service failed | Restart service |
| 5 | Memory exceeded | Free memory |
| 6 | Disk full | Clear space |
| 127 | Command not found | Install missing tool |

### Error Messages

**Format**:
```bash
[LEVEL] [TIMESTAMP] [SERVICE]: Message
```

**Levels**:
- `INFO`: Informational
- `WARN`: Warning condition
- `ERROR`: Error occurred
- `FATAL`: Fatal error, stopping

### Recovery Strategies

1. **Service Failure**: Automatic restart with exponential backoff
2. **Memory Pressure**: Service throttling and cache clearing
3. **Disk Full**: Log rotation and temp file cleanup
4. **Display Error**: Fallback to terminal mode

---

## Usage Examples

### Starting JesterOS
```bash
# Full initialization
/usr/local/bin/init-jesteros.sh

# Start specific service
jesteros-service-manager.sh start jester

# Monitor all services
jesteros-service-manager.sh monitor
```

### Reading Statistics
```bash
# Get writing stats
cat /var/jesteros/typewriter/stats

# Check current mood
cat /var/jesteros/jester/mood

# View health status
cat /var/jesteros/health/status
```

### Service Management
```bash
# Restart all services
jesteros-service-manager.sh restart all

# Check service health
jesteros-service-manager.sh health

# Stop specific service
jesteros-service-manager.sh stop tracker
```

---

## Performance Specifications

### Memory Limits
- Total OS: < 96MB
- Per service: < 5MB
- Service manager: < 2MB
- Menu system: < 2MB

### Timing Requirements
- Boot time: < 10 seconds
- Service startup: < 2 seconds
- Menu response: < 500ms
- File save: < 1 second

### Update Frequencies
- Jester mood: 30 seconds
- Writing stats: 60 seconds
- Health check: 60 seconds
- Achievement check: On file save

---

## Version History

### v2.0.0 (Current)
- Migrated to userspace services
- Removed kernel module dependency
- Added achievement system
- Improved error handling

### v1.0.0
- Initial kernel module implementation
- Basic /proc interface
- Simple statistics tracking

---

## See Also

- [JESTEROS_API_COMPLETE.md](JESTEROS_API_COMPLETE.md) - Complete service API reference
- [SCRIPTS_DOCUMENTATION_COMPLETE.md](SCRIPTS_DOCUMENTATION_COMPLETE.md) - All scripts documented
- [API_NAVIGATION_INDEX.md](API_NAVIGATION_INDEX.md) - Documentation navigation

---

*"By quill and code, we craft digital magic!"* 🎭📜

**Generated**: August 15, 2025  
**Framework**: JesterOS Userspace Architecture  
**Compatibility**: Nook Simple Touch, Linux 2.6.29